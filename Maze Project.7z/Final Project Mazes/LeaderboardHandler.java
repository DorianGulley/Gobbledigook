import java.io.*;
import java.util.Scanner;
import java.util.Arrays;

/**
 * This class handles the leaderboard file
 * The file contains the best completion times of all mazes in order
 */
public class LeaderboardHandler {

  //The leaderboard file
  private static final File LEADERBOARD = new File("leaderboard.txt");
  //The maximum number of entries in the leaderboard
  private static final int MAX_ENTRIES = 5;

  /**
   * Inserts a specified time in the correct location of the leaderboard file
   * This is the file output requriment for the project
   * @param time The time to be inserted in the file
   */
  public static void insert(long time) throws FileNotFoundException {
    long[] originalList = leaderboardAsList();
    long[] list = Arrays.copyOf(originalList, originalList.length + 1);
    list[list.length - 1] = time;
    Arrays.sort(list);
    if (list.length > MAX_ENTRIES) {
        list = Arrays.copyOf(list, MAX_ENTRIES);
    }

    PrintWriter writer = new PrintWriter(LEADERBOARD);

    for (int i = 0; i < list.length; i++) {
      writer.write(list[i] + ",");
    }
    writer.close();
  }

  /**
   * Returns a string representation of the leaderboard
   * This is the file input requirement for the project
   * @return A string representation of the leaderboard
   */
  public static String leaderboardAsString() throws FileNotFoundException {
    Scanner in = new Scanner(LEADERBOARD);
    in.useDelimiter(",");
    
    if (! in.hasNextLong()) {
        return "Empty";
    }
    
    String out = "";

    for (int i = 0; in.hasNextLong(); i++) {
        out += i + 1 + ". " + in.nextLong() + " seconds\n";
    }
    in.close();

    return out;
  }

  /**
   * Returns an array representing the leaderboard
   * This is the file input requirement for the project
   * @return An array representing the leaderboard
   */
  private static long[] leaderboardAsList() throws FileNotFoundException{
    Scanner in = new Scanner(LEADERBOARD);
    in.useDelimiter(",");
    
    long[] list = new long[0];

    for (int i = 0; in.hasNextLong(); i++) {
      list = Arrays.copyOf(list, list.length + 1);
      list[i] = in.nextLong();
    }
    in.close();

    return list;
  }
}