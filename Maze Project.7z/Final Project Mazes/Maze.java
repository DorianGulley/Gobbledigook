import java.awt.Point;
import java.util.ArrayList;

/**
 * This class defines a maze and its properties
 */
public class Maze {
    
    //The list of walls for the maze
    private ArrayList<Wall> walls;
    //The start location of the maze
    private Point start;
    //The goal location of the maze
    private Point finish;
    
    /**
     * Constructor for the maze class
     * Initializes the walls, start location, and goal location
     * @param walls The list of walls for the maze
     * @param start The start location of the maze
     * @param finish The goal location of the maze
     */
    public Maze(ArrayList<Wall> walls, Point start, Point finish) {
        this.walls = walls;
        this.start = start;
        this.finish = finish;
    }
    
    /**
     * Returns the start location of the maze
     * @return The start location of the maze
     */
    public Point getStart() {
        return start;
    }
    
    /**
     * Returns the goal location of the maze
     * @return The goal location of the maze
     */
    public Point getFinish() {
        return finish;
    }
    
    /**
     * Returns whether or not the maze has a wall at the specified location
     * @param location The location to check
     * @return True if the maze has a wall at the location, false otherwise
     */
    public boolean hasWallAt(Point location) {
        for (Wall wall: walls) {
            if (wall.getLocation().equals(location)) return true;
        }
        return false;
    }
}