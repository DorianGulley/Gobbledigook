import java.awt.Point;

/**
 * This class manages the player's location and movement
 */
public class Player {
    
    //The player's location
    private Point location;
    
    /**
     * Constructor for the player class
     * Initially sets the location to null
     */
    public Player() {
        location = null;
    }
    
    /**
     * Sets the player's position to the specified location
     * @param location The location to set the player at
     */
    public void setLocation(Point location) {
        this.location = location;
    }
    
    /**
     * Moves the player
     * @param dx The distance to move the player across the x-axis
     * @param dy The distance to move the player across the y-axis
     */
    public void move(int dx, int dy) {
        location.translate(dx, dy);
    }
    
    /**
     * Returns the player's location
     * @return The player's location
     */
    public Point getLocation() {
        return location;
    }
}