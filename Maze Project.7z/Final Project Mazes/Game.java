import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.awt.*;

/**
 * This is the main class of the project
 * It handles the GUI for the maze and runs the game loop
 * This is the GUI requirement for the project
 */
class Game extends JFrame{
    
    //The current level being played
    private int level;
    //The player
    private Player player;
    //The current maze being played
    private Maze maze;   
    //The grid of cells in the maze
    private JPanel[][] grid;
    //The label displaying the current level 
    //or the completion time if the maze has been completed
    //The label showing how to play
    private JLabel levelLabel, instructionsLabel;
    //The button used to show the leaderboard
    private JButton leaderboardButton;
    //The panel containing all of the elements
    //The panel containing the elements in the upper section
    //The panel containing the elements in the lower section
    //The panel that contains the cells of the grid
    private JPanel thePanel, upperPanel, lowerPanel, gridContainer;
    //The text area that displays the leaderboard
    private JTextArea leaderboardTextArea;
    //The total number of levels in the game
    private static final int TOTAL_LEVELS = 6;
    //The number of cells that represent the maze widths
    private static final int LEVEL_WIDTH = 11;
    //The number of cells that represent the maze heights
    private static final int LEVEL_HEIGHT = 11;
    //The width of the frame
    private static final int FRAME_WIDTH = 500;
    //The height of the frame
    private static final int FRAME_HEIGHT = 500;
    
    /**
     * Creates a new game
     */
    public static void main(String[] args) throws FileNotFoundException{
        new Game();
    }
       
    /**
     * Initializes the elements of the game
     * Sets up the frame
     * Sets up the layout for the GUI
     * Adds the necessary listeners for keys and button press
     * Runs the game loop
     */
    private Game() throws FileNotFoundException {
        level = 1;
        player = new Player();
        
        this.setTitle("Maze Challenge");
        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
                
        thePanel = new JPanel();
        thePanel.setLayout(new BorderLayout());
        
        upperPanel = new JPanel();
        upperPanel.setLayout(new GridLayout(1, 2));
        levelLabel = new JLabel();
        levelLabel.setText("Level 1");
        instructionsLabel = new JLabel();
        instructionsLabel.setText("Use WASD or arrow keys to move");
        upperPanel.add(levelLabel);
        upperPanel.add(instructionsLabel);
        thePanel.add(upperPanel, BorderLayout.NORTH);
        
        gridContainer = new JPanel();
        gridContainer.setLayout(new GridLayout(LEVEL_HEIGHT, LEVEL_WIDTH));
        grid = new JPanel[LEVEL_WIDTH][LEVEL_HEIGHT];
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {
                grid[x][y] = new JPanel();
                gridContainer.add(grid[x][y]);
            }
        }
        thePanel.add(gridContainer, BorderLayout.CENTER);
        
        lowerPanel = new JPanel();
        lowerPanel.setLayout(new GridLayout(1, 2));
        leaderboardButton = new JButton();
        leaderboardButton.setText("Leaderboard");
        leaderboardButton.addActionListener(new ListenForButton());
        leaderboardButton.setFocusable(false);
        leaderboardTextArea = new JTextArea();
        leaderboardTextArea.setText("");
        leaderboardTextArea.setFocusable(false);
        lowerPanel.add(leaderboardButton);
        lowerPanel.add(leaderboardTextArea);
        thePanel.add(lowerPanel, BorderLayout.SOUTH);
        
        this.add(thePanel);
        this.addKeyListener(new ListenForKeys());
        this.setVisible(true);
        
        play();
    }
    
    /**
     * Runs the game loop
     * Updates the level each iteration
     * Checks the completion time at the end
     */
    private void play() throws FileNotFoundException{
        long startTime = System.currentTimeMillis();
        while (true) {
            maze = MazeDataReader.getMaze(level);
            player.setLocation(maze.getStart());
            update();
            while (! player.getLocation().equals(maze.getFinish())) {}                          
            level++;
            if (level == TOTAL_LEVELS) {
                long endTime = System.currentTimeMillis();
                long time = (endTime - startTime) / 1000;
                LeaderboardHandler.insert(time);
                levelLabel.setText("You win! Time: " + time + " seconds");
            } else {
                levelLabel.setText("Level " + level);
            }
        }
    }    
    
    /**
     * Updates the grid
     * A black cell denotes a wall
     * A blue cell denotes the player
     * A red cell denotes the goal
     * A white cell denotes empty space
     */
    private void update() {
       Point finish = maze.getFinish();
       for (int y = 0; y < grid.length; y++) {
           for (int x = 0; x < grid[0].length; x++) {
               Point thisPoint = new Point(x, y);
               if (maze.hasWallAt(thisPoint)) {
                   grid[x][y].setBackground(Color.BLACK);
               } else if (player.getLocation().equals(thisPoint)) {
                   grid[x][y].setBackground(Color.BLUE);
               } else if (finish != null && finish.equals(thisPoint)) {
                   grid[x][y].setBackground(Color.RED);
               } else {
                   grid[x][y].setBackground(Color.WHITE);
               }
           }
       }
    }
    
    /**
     * This class listens for a button click
     * Updates the leaderboard text area upon click
     */
    private class ListenForButton implements ActionListener { 
        
        /**
         * Updates the leaderboard text area if the button is clicked
         */
        public void actionPerformed(ActionEvent e) {           
            if (e.getSource() == leaderboardButton) {
                if (leaderboardTextArea.getText().equals("")) {
                    try {
                        leaderboardTextArea.setText(LeaderboardHandler.leaderboardAsString());
                    } catch (FileNotFoundException fnfe) {
                        leaderboardTextArea.setText("Problem loading leaderboard");
                    }
                } else {
                    leaderboardTextArea.setText("");
                }
            }
        }
    }
    
    /**
     * This class listens for key presses
     * It moves the player if the WASD or arrow keys are pressed
     * only if the key has been released since the lass check
     */
    private class ListenForKeys implements KeyListener { 
        //Whether or not a key has been released
        boolean released = true;
        
        /**
         * Moves the player if the WASD or arrow keys have been pressed
         * only if a key has been released since the last check
         * Moves the player back if it tries to enter a wall
         */
        public void keyPressed(KeyEvent e) {
            if (released == true) {
                released = false;
                
                int typed = e.getKeyCode();
                int dx = 0, dy = 0;
                
                if (typed == KeyEvent.VK_W || typed == KeyEvent.VK_UP) {
                    dy--;
                } else if (typed == KeyEvent.VK_A || typed == KeyEvent.VK_LEFT) {
                    dx--;
                } else if (typed == KeyEvent.VK_S || typed == KeyEvent.VK_DOWN) {
                    dy++;
                } else if (typed == KeyEvent.VK_D || typed == KeyEvent.VK_RIGHT) {
                    dx++;
                }
                player.move(dx, dy);
                
                if (maze.hasWallAt(player.getLocation())) {
                    player.move(-dx, -dy);
                }
            }
            update();
        }
        
        public void keyTyped(KeyEvent e) {}
        
        /**
         * Sets that a key has been released since the last check to true
         */
        public void keyReleased(KeyEvent e) {
            released = true;
        }
    }
}