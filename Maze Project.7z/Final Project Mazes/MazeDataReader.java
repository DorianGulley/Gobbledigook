import java.util.Scanner;
import java.util.ArrayList;
import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * This class solely reads the maze data files
 * and returns the maze of interest
 */
public class MazeDataReader {
    
    //File data that specifies a wall
    private static final int WALL_DATA = 1;
    //File data that specifies the start location
    private static final int START_DATA = 2;
    //File data that specifies the goal location
    private static final int FINISH_DATA = 3;
    
    /**
     * Returns the maze specified by the level number
     * This is the file input requirement for the project
     * @return The maze specified by the level number
     */
    public static Maze getMaze(int level) throws FileNotFoundException {
        //The file associated with the level
        File file = new File("mazedata\\level" + level + ".txt");
        //The scanner that reads the file
        Scanner in = new Scanner(file);
        //The list of walls associated with the maze
        ArrayList<Wall> walls = new ArrayList<Wall>();
        //The start location of the maze
        Point start = null;
        //The goal location of the maze
        Point finish = null;
        
        for (int y = 0; in.hasNextLine(); y++) {
            Scanner reader = new Scanner(in.nextLine());
            reader.useDelimiter(",");
            for (int x = 0; reader.hasNextInt(); x++) {
                int data = reader.nextInt();
                Point thisPoint = new Point(x, y);
                if (data == WALL_DATA) walls.add(new Wall(thisPoint));
                else if (data == START_DATA) start = thisPoint;
                else if (data == FINISH_DATA) finish = thisPoint;
            }
        }
        
        return new Maze(walls, start, finish);
    }
}