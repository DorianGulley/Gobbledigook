import java.awt.Point;

/**
 * This class manages the locations of the maze's walls
 */
public class Wall
{
    //The wall's location
    private Point location;

    /**
     * Constructor for the wall class
     * Sets the location of the wall to the specified location
     * @param location The location of the wall
     */
    public Wall(Point location)
    {
        this.location = location;
    }

    /**
     * Returns the location of the wall
     * @return The location of the wall
     */
    public Point getLocation() {
        return location;
    }
}
